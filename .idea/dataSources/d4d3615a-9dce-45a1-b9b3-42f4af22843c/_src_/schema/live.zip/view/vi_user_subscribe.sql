CREATE VIEW `vi_user_subscribe` AS
  SELECT
    `u`.`user_id`            AS `user_id`,
    `u`.`user_name`          AS `user_name`,
    `r`.`room_id`            AS `room_id`,
    `r`.`room_name`          AS `room_name`,
    `us`.`user_subscribe_id` AS `user_subscribe_id`,
    `r`.`user_id`            AS `anchor_id`
  FROM ((`live`.`user_subscribe` `us` LEFT JOIN `live`.`user` `u` ON ((`us`.`user_id` = `u`.`user_id`))) LEFT JOIN
    `live`.`room` `r` ON ((`r`.`room_id` = `us`.`room_id`)))