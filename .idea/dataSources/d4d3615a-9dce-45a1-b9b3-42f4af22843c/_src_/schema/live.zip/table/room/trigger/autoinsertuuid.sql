CREATE TRIGGER `autoinsertuuid`
BEFORE INSERT ON `room`
FOR EACH ROW
  if(new.stream_key='' or new.stream_key is null) then  set new.stream_key=uuid(); end if