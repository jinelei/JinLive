CREATE VIEW `vi_user_subscribe` AS
  SELECT
    `r`.`room_id`            AS `room_id`,
    `r`.`room_name`          AS `room_name`,
    `r`.`room_status`        AS `room_status`,
    `r`.`room_screenshot`    AS `room_screenshot`,
    `r`.`room_introduce`     AS `room_introduce`,
    `r`.`stream_key`         AS `stream_key`,
    `rc`.`category_id`       AS `category_id`,
    `c`.`category_name`      AS `category_name`,
    `c`.`category_introduce` AS `category_introduce`,
    `r`.`user_id`            AS `user_id`,
    `u`.`user_name`          AS `user_name`,
    `u`.`user_nickname`      AS `user_nickname`,
    `u`.`user_sex`           AS `user_sex`,
    `u`.`user_age`           AS `user_age`,
    `u`.`user_phone`         AS `user_phone`,
    `u`.`user_email`         AS `user_email`,
    `u`.`user_height`        AS `user_height`,
    `u`.`user_weight`        AS `user_weight`,
    `u`.`user_area`          AS `user_area`,
    `u`.`user_status`        AS `user_status`,
    `u`.`user_treasure`      AS `user_treasure`,
    `us`.`user_id`           AS `subscriber_id`
  FROM ((((`live`.`user_subscribe` `us` LEFT JOIN `live`.`room_category` `rc`
      ON ((`us`.`room_id` = `rc`.`room_id`))) LEFT JOIN `live`.`room` `r`
      ON ((`r`.`room_id` = `us`.`room_id`))) LEFT JOIN `live`.`user` `u` ON ((`u`.`user_id` = `r`.`user_id`))) LEFT JOIN
    `live`.`category` `c` ON ((`c`.`category_id` = `rc`.`category_id`)))